package com.example.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entity.Booking;

import feign.Headers;

@Headers("Content-Type: application/json")

@FeignClient(name = "Booking-Service", url = "${SHOWTIME_SERVICE:http://localhost:9300}"/*, 
													fallback = PatientFeignFallback.class*/)
public interface BookingFeignclient {
	@GetMapping("/api/bookings/showtime/{bookingId}")
	List<Booking>getBookingById(@PathVariable("bookingId") Long bookingId);
	

}
