package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;
import com.example.demo.service.IUserService;

import jakarta.validation.Valid;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api/users")
public class UserController {

	
    @Autowired
    private IUserService userService;

    //http://localhost:9200/users
    @PostMapping
    public User createUser(@Valid @RequestBody User user) {
        return userService.createUser(user);
    }

//    @PostMapping("/login")
//       public ResponseEntity<?> authenticateUser(@RequestBody User loginRequest) {
//           // Authenticate the user
//           User user = userService.findByUsername(loginRequest.getUsername());
//
//           if (user != null && user.getPassword().equals(loginRequest.getPassword())) {
//               return ResponseEntity.ok(Collections.singletonMap("valid", true));
//           } else {
//               return ResponseEntity.ok(Collections.singletonMap("valid", false));
//           }
//       }
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody User loginRequest) {
        // Authenticate the user
        User user = userService.findByUsername(loginRequest.getUsername());

        if (user != null && user.getPassword().equals(loginRequest.getPassword())) {
            // Create a map to hold the response data
            Map<String, Object> response = new HashMap<>();
            response.put("valid", true);
            response.put("user", user); // Add the user object to the response

            return ResponseEntity.ok(response);
        } else {
            // If authentication fails, return valid as false
            return ResponseEntity.ok(Collections.singletonMap("valid", false));
        }
    }

    //http://localhost:9200/users/1
    @GetMapping("/{id}")
    public Optional<User> getUser(@PathVariable Long id) {
        return userService.getUser(id);
    }
    //http://localhost:9200/users
    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    // http://localhost:9200/users/{id}
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @Valid @RequestBody User user) {
        return userService.updateUser(id, user);
    }
//http://localhost:9101/users/{id}
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }
}
