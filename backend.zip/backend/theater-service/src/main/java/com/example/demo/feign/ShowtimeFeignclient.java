package com.example.demo.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.entity.Showtime;

import feign.Headers;

@Headers("Content-Type: application/json")

@FeignClient(name = "showtime-management", url = "${SHOWTIME_SERVICE:http://localhost:9101}"/*, 
													fallback = PatientFeignFallback.class*/)
public interface ShowtimeFeignclient {
	@GetMapping("/showtimes/theater/{theaterId}")
	List<Showtime>getShowtimesByTheaterId(@PathVariable("theaterId") Long theaterId);
	

}
