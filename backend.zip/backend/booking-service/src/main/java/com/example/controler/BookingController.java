package com.example.controler;

import com.example.entity.Booking;
import com.example.repository.BookingRepository;
import com.example.service.BookingService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    @Autowired
    private BookingService bookingService;
    @Autowired
    private BookingRepository bookingRepo;

    //http://localhost:9300/api/bookings
    @PostMapping( consumes = "application/json", produces = "application/json")
         public Booking createBooking(@Valid @RequestBody Booking booking) {
        return bookingService.createBooking(booking);
    }
    @GetMapping
    public List<Booking> getAllBookings(){
    	return bookingRepo.findAll();
    }
    
    //http://localhost:9300/api/bookings/1
    @GetMapping("/{bookingId}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long bookingId) {
        Optional<Booking> booking = bookingService.getBookingById(bookingId);
        return booking.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    //http://localhost:9300/api/bookings/user/1
    @GetMapping("/user/{userId}")
    public List<Booking> getAllBookingsForUser(@PathVariable Long userId) {
        return bookingService.getAllBookingsForUser(userId);
    }
    //http://localhost:9300/api/bookings/showtime
    @GetMapping("/showtime/{showtimeId}")
    public List<Booking> getAllBookingsForShowtimeId(@PathVariable Long showtimeId) {
        return bookingRepo.findByShowtimeId(showtimeId);
    }
    
    //http://localhost:9300/api/bookings/2
    @PutMapping("/{bookingId}")
    public ResponseEntity<Booking> updateBooking(@PathVariable Long bookingId, @Valid @RequestBody Booking bookingDetails) {
        return ResponseEntity.ok(bookingService.updateBooking(bookingId, bookingDetails));
    }

    @DeleteMapping("/{bookingId}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long bookingId) {
        bookingService.deleteBooking(bookingId);
        return ResponseEntity.ok().build();
    }
}
