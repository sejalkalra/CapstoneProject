import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable, of, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  userid!:any;
  private apiUrl = 'http://localhost:9200/api/users/login'; // Update with your actual backend API URL

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<{ valid: boolean, user?: any }> {
    return this.http.post<{ valid: boolean, user?: any }>(this.apiUrl, { username, password }).pipe(
      tap(response => {
        if (response.valid) {
          console.log("response", response);
          this.userid=response.user.userId;
          this.setAuthenticated(true);
          // Optionally, store user data in localStorage if needed
          localStorage.setItem('user', JSON.stringify(response.user));
        } else {
          this.setAuthenticated(false);
        }
      })
    );
  }

  logout(): void {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('user');
  }

  isAuthenticated(): Observable<boolean> {
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    return of(isAuthenticated);
  }

  setAuthenticated(isAuthenticated: boolean): void {
    localStorage.setItem('isAuthenticated', isAuthenticated.toString());
    localStorage.setItem('userid',this.userid);
  }



  // login(username: string, password: string): Observable<{ valid: boolean }> {
  //   return this.http.post<{ valid: boolean }>(this.apiUrl, { username, password }).pipe(
  //     tap(response => {
  //       if (response.valid) {
  //         this.setAuthenticated(true);
  //       }
  //     })
  //   );
  // }

  // logout(): void {
  //   localStorage.removeItem('isAuthenticated');
  // }

  // isAuthenticated(): Observable<boolean> {
  //   const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  //   return of(isAuthenticated);
  // }

  // setAuthenticated(isAuthenticated: boolean): void {
  //   localStorage.setItem('isAuthenticated', isAuthenticated.toString());
  // }



}
