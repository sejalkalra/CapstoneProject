import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Movie } from '../../model/movie';

@Component({
  selector: 'app-movie-edit',
  templateUrl: './movie-edit.component.html',
  styleUrls: ['./movie-edit.component.css']
})
export class MovieEditComponent  {
  movieAdd: Movie = new Movie();
  constructor(private movService: MovieService,
    private route: ActivatedRoute,
    private router:Router,) {}

    showError:boolean=false;
    ngOnInit(): void {
      this.route.paramMap.subscribe((param) => {
        //editt:101 = @Path Varaible
        var movieId = Number(param.get('movieId')); // Read the product id from route
        this.getById(movieId);

      });
    }

    getById(movieId: number) {
      this.movService.getById(movieId).subscribe((data) => {
      console.log(data);
        this.movieAdd = data;
      });
    }

update() {
  this.showError=true;
  if(this.onValidation()){
    this.showError=false;
    this.movService.update(this.movieAdd)
    .subscribe({
      next:(data) => {
        this.router.navigate(["/home/movie"]);
      },
      // error:(err) => {
      //   console.log(err);
      // }
    })
  }
  }

  cancel(){
    this.router.navigate(['/home/movie'])
    .then(() =>
    {
      window.location.reload();
    });


  }
  onValidation(){
    return this.movieAdd.description&&this.movieAdd.duration&&this.movieAdd.genre&& this.movieAdd.rating <= 10 &&this.movieAdd.title;
}
}
