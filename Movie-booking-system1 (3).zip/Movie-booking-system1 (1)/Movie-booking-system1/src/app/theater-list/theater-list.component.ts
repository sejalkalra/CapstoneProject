import { Component, OnInit } from '@angular/core';
import { TheaterService } from '../theater.service';
import { Theater } from '../../model/theater';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-theater-list',
  templateUrl: './theater-list.component.html',
  styleUrl: './theater-list.component.css'
})
export class TheaterListComponent implements OnInit {
  theaters: Theater[] = [];
  userid:any;
  user:any;
  showUsers:boolean=false;
  constructor(private theaterService: TheaterService,private router:Router,private userservice:UserService) {}

  ngOnInit(): void {

    this.userid=localStorage.getItem("userid");
    // console.log("userid",userid);


      this.userservice.getById(this.userid).subscribe({
        next: (user) => {
          this.user = user;
          console.log("user",user);
          if(user.role==='user')
          {
            this.showUsers=true;
            console.log("this is user");

          } else if(user.role==='admin'){
            console.log("this is admin");

          }

        },
        error: (err) => {
          console.error('Error fetching user details', err);

        }
      });

    this.loadTheaters();
  }

  loadTheaters(): void {
    this.theaterService.getTheaters().subscribe((data) => {
      this.theaters = data;
    });
  }

  deleteTheater(id: number): void {
    this.theaterService.deleteTheater(id).subscribe(() => {
      this.loadTheaters();
    });
  }

  searchQuery: string = '';
  filterMovies() {
    if (this.searchQuery.trim() === '') {
    }else{
      this.theaters = this.theaters.filter((t) =>
        t.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );}
    }

  clear(){
    this.router.navigate(['/home/theater'])
    .then(() =>
    {
      window.location.reload();
    });


  }

}
