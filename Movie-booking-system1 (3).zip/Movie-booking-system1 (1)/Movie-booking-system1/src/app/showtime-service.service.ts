import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Showtime } from '../model/Showtime.model';
//import { Showtime } from './showtime.model';

@Injectable({
  providedIn: 'root'
})
export class ShowtimeService {
  private baseUrl = 'http://localhost:9101/showtimes';
  addShowtime: any;

  constructor(private http: HttpClient) { }

  getBookingForShowtime(showId:number){
    return this.http.get<any[]>(`${this.baseUrl}/${showId}/booking`)
  }
  getAllShowtimes(): Observable<Showtime[]> {
    return this.http.get<Showtime[]>(`${this.baseUrl}/all`);
  }


  getShowtimeById(id: number): Observable<Showtime> {
    return this.http.get<Showtime>(`${this.baseUrl}/getshow/${id}`);
  }

  createShowtime(showtime: Showtime): Observable<Showtime> {
    return this.http.post<Showtime>(`${this.baseUrl}/addshow`, showtime);
  }

  updateShowtime(id: number, showtime: Showtime): Observable<Showtime> {
    return this.http.put<Showtime>(`${this.baseUrl}/editshow/${id}`, showtime);
  }

  deleteShowtime(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/deleteshow/${id}`);
  }

  getShowtimesByMovie(movieId: number): Observable<Showtime[]> {
    return this.http.get<Showtime[]>(`${this.baseUrl}/movie/${movieId}`);
  }
  getShowtimesBymov(movieId: number) {
    //return this.http.get<Product>(`http://localhost:3000/products/${id}`);
    console.log('');
    return this.http.get<Showtime>(`http://localhost:9101/showtimes/movie/${movieId}`);
   }

  getShowtimesByTheater(theaterId: number): Observable<Showtime[]> {
    return this.http.get<Showtime[]>(`${this.baseUrl}/theater/${theaterId}`);
  }
  getShowtimesByth(theaterId: number) {
    //return this.http.get<Product>(`http://localhost:3000/products/${id}`);
    console.log('');
    return this.http.get<Showtime>(`http://localhost:9101/showtimes/theater/${theaterId}`);
   }
}
