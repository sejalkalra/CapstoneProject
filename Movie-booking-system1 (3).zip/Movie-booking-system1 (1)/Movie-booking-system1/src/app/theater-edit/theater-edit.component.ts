import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TheaterService } from '../theater.service';
import { Theater } from '../../model/theater';
import { LoginComponent } from '../login/login.component';
//import { Theater } from '../theater.model';

@Component({
  selector: 'app-theater-edit',
  templateUrl: './theater-edit.component.html',
})
export class TheaterEditComponent implements OnInit {
 // theater: Theater = { theaterId: 0, name: '', location: '', capacity: 0 };
 showError:boolean=false;
 theater: Theater = new Theater();
  constructor(
    private theaterService: TheaterService,
    private route: ActivatedRoute,
    private router: Router
  ) {}


  ngOnInit(): void {
    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      var theaterId = Number(param.get('theaterId')); // Read the product id from route
      this.getById(theaterId);

    });
  }

  getById(theaterId: number) {
    this.theaterService.getById(theaterId).subscribe((data) => {
    console.log(data);
      this.theater = data;
    });
  }

  // updateTheater(): void {
  //   this.showError=true;
  //   if(this.onValidation()){
  //     this.showError=false;
  //   this.theaterService.updateTheater(this.theater).subscribe({
  //     next:(data) => {
  //       this.router.navigate(["/home/theater"]);
  //     },
  //     // error:(err) => {
  //     //   console.log(err);
  //     // }
  //   })
  // }
 // }
 updateTheater(): void {
  this.showError = true;
  if (this.onValidation()) {
    this.showError = false;
    this.theaterService.updateTheater(this.theater).subscribe({
      next: () => {
        this.router.navigate(['/home/theater']);
      },
      error: (err) => {
        console.error('Error updating theater:', err);
      }
    });
  }
}
//  updateTheater(): void {
//   console.log(this.theater);

//   this.theaterService.updateTheater(this.theater).subscribe(() => {
//     this.router.navigate(['/home/theater']);
//   });
// }

  clear(){
    this.router.navigate(['/home/theater'])
    .then(() =>
    {
      window.location.reload();
    });

  }
  onValidation(){
return this.theater.name&&this.theater.capacity&&this.theater.location;}
}
