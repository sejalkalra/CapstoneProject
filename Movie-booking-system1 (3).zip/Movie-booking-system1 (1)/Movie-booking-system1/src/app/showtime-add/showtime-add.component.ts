import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ShowtimeService } from '../showtime-service.service';
import { Showtime } from '../../model/Showtime.model';
import { MovieService } from '../movie.service';
import { TheaterService } from '../theater.service';
import { Theater } from '../../model/theater';

@Component({
  selector: 'app-showtime-add',
  templateUrl: './showtime-add.component.html',
  styleUrls: ['./showtime-add.component.css']
})
export class ShowtimeAddComponent {

  movieList:any
  showtime: Showtime = new Showtime(); // Initialize with default or empty values
theaterList: Theater[]=[]
  // constructor(private showtimeService: ShowtimeService, private router: Router,
  //   private movieservice:MovieService,
  //   private theaterservice:TheaterService
  // ) {
  //   this.movieservice.getUserData().subscribe(data=>{
  //     this.movieList=data
  //   })
  //   this.theaterservice.getTheaters().subscribe(data=>{
  //     this.theaterList=data

  //   })
  // }

  // onSubmit() {
  //   this.showtimeService.createShowtime(this.showtime).subscribe( {
  //     next:(data)=>{
  //     this.router.navigate(['/home/showtime-list']); // Navigate to /showtimes after adding
  //   }, error: (err)=> {
  //     console.error('Error adding showtime:', err); // Handle error if necessary
  //   }});
  // }

  constructor(private showtimeService: ShowtimeService, private router: Router,
    private movieservice:MovieService,
    private theaterservice:TheaterService
  ) {
    this.movieservice.getUserData().subscribe(data=>{
      this.movieList=data
    })
    this.theaterservice.getTheaters().subscribe(data=>{
      this.theaterList=data

    })
  }

  // onSubmit() {
  //   this.showtimeService.createShowtime(this.showtime).subscribe( {
  //     next:(data)=>{
  //     this.router.navigate(['/home/showtime-list']); // Navigate to /showtimes after adding
  //   }, error: (err)=> {
  //     console.error('Error adding showtime:', err); // Handle error if necessary
  //   }});
  // }
  onSubmit() {
    this.showtimeService.createShowtime(this.showtime).subscribe( {
      next:(data)=>{
      this.router.navigate(['/home/showtime-list']); // Navigate to /showtimes after adding
    }, error: (err)=> {
      console.error('Error adding showtime:', err); // Handle error if necessary
    }});
  }

  clear(){
    this.router.navigate(['/home/showtime-list'])
    .then(() =>
    {
      window.location.reload();
    });

  }
}
