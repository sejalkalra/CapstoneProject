import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { User } from '../../model/User';
import { MatSidenav } from '@angular/material/sidenav';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
//   constructor(private router: Router) {}

//   navigateTo(page: string) {
//     this.router.navigate([`/${page}`]);
//   }
//   logout() {
//     this.router.navigate(['/login']);
//   }
// }

constructor(private router: Router,private userservice:UserService) {}
userList:User | undefined;
userid!:any;
user:any;
showUsers:boolean=false;
@ViewChild('sidenav') sidenav!: MatSidenav;

toggleSidenav() {
  this.sidenav.toggle();
}


ngOnInit(){

  this.userid=localStorage.getItem("userid");
  // console.log("userid",userid);


    this.userservice.getById(this.userid).subscribe({
      next: (user) => {
        this.user = user;
        console.log("user",user);
        if(user.role==='user')
        {
          this.showUsers=true;
          console.log("this is user");

        } else if(user.role==='admin'){
          console.log("this is admin");

        }

      },
      error: (err) => {
        console.error('Error fetching user details', err);

      }
    });



}


navigateTo(page: string) {
  this.router.navigate([`/${page}`]);
}

logout() {

  localStorage.removeItem("userid");
  localStorage.removeItem("user");
  // Implement your logout logic here, e.g., clearing tokens, redirecting to login
  this.router.navigate(['/login']);
}
}
