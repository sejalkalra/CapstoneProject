import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { BookingAddComponent } from './booking-add/booking-add.component';
import { BookingEditComponent } from './booking-edit/booking-edit.component';
import { AuthGuard } from './auth.guard';
import { TheaterListComponent } from './theater-list/theater-list.component';
import { TheaterAddComponent } from './theater-add/theater-add.component';
import { TheaterEditComponent } from './theater-edit/theater-edit.component';
import { LoginComponent } from './login/login.component';
import { MovieAddComponent } from './movie-add/movie-add.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieEditComponent } from './movie-edit/movie-edit.component';
import { ShowtimeEditComponent } from './showtime-edit/showtime-edit.component';
import { ShowtimeAddComponent } from './showtime-add/showtime-add.component';
import { ShowtimeListComponent } from './showtime-list/showtime-list.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserUpdateComponent } from './user-update/user-update.component';
import { UserAddComponent } from './user-add/user-add.component';
import { MovieshowtimelistComponent } from './movieshowtimelist/movieshowtimelist.component';
import { TheatershowtimeComponent } from './theatershowtime/theatershowtime.component';
import { BookingshowtimeComponent } from './bookingshowtime/bookingshowtime.component';

const routes: Routes = [

  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup',component:UserAddComponent},
  {
    path: 'home',component: HomeComponent,canActivate: [AuthGuard],
    children: [
      { path: 'movie', component: MovieListComponent , canActivate: [AuthGuard]},
      { path: 'movie-add', component: MovieAddComponent, canActivate: [AuthGuard]},
      { path: 'movie-edit/:movieId', component: MovieEditComponent , canActivate: [AuthGuard]},

      { path: 'theater', component: TheaterListComponent , canActivate: [AuthGuard]},
      { path: 'theater-add', component: TheaterAddComponent , canActivate: [AuthGuard]},
      { path: 'theater-edit/:theaterId', component: TheaterEditComponent , canActivate: [AuthGuard],},

      { path: 'showtime-edit/:id', component: ShowtimeEditComponent , canActivate: [AuthGuard]},
      { path: 'showtime-add', component: ShowtimeAddComponent, canActivate: [AuthGuard]},
      { path: 'showtime', component: ShowtimeListComponent , canActivate: [AuthGuard]},
      { path: 'showtime-list', component: ShowtimeListComponent , canActivate: [AuthGuard]},
      { path: 'showtime-list/:theaterId', component: TheatershowtimeComponent , canActivate: [AuthGuard]},
      // { path: 'showtime-list-m/:movieId', component: ShowtimeListComponent , canActivate: [AuthGuard]},
      { path: 'showtime-list-m/:movieId', component: MovieshowtimelistComponent , canActivate: [AuthGuard]},

      { path: 'user', component: UserListComponent , canActivate: [AuthGuard]},
      { path: 'New1', component: UserAddComponent , canActivate: [AuthGuard]},
      { path: 'edit-user/:userId', component: UserUpdateComponent, canActivate: [AuthGuard]},

      { path: 'booking-list', component: BookingListComponent , canActivate: [AuthGuard]},
      { path: 'booking-li/:showtimeId', component: BookingshowtimeComponent , canActivate: [AuthGuard]},
      { path: 'booking-add', component: BookingAddComponent, canActivate: [AuthGuard]},
      { path: 'booking-edit/:id', component: BookingEditComponent, canActivate: [AuthGuard]},

    ]
  },
  // { path: '**', redirectTo: 'login' }
  ];


  // { path: 'login', component: LoginComponent },
  // {path: "home", component:HomeComponent},
  // { path: 'booking-list', component: BookingListComponent },
  // { path: 'booking-list/:showId', component: BookingListComponent },
  // { path: 'movies', component: MovieListComponent },
  // {path:'New',component :MovieAddComponent},
  // { path: 'Edit/:movieId', component: MovieEditComponent},
  // { path: 'booking-add', component: BookingAddComponent},
  // { path: 'booking-edit/:id', component: BookingEditComponent},
  // { path: 'theaters', component: TheaterListComponent },
  // { path: 'theater-add', component: TheaterAddComponent },
  // { path: 'theater-edit/:id', component: TheaterEditComponent },
  // { path: 'showtime-edit/:id', component: ShowtimeEditComponent },
  // { path: 'showtime-add', component: ShowtimeAddComponent},
  // { path: 'showtime-list', component: ShowtimeListComponent },
  // { path: 'users', component: UserListComponent },
  // { path: 'New1', component: UserAddComponent },
  // { path: 'edit-user/:userId', component: UserUpdateComponent},



// ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
