import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie.service';

import { Router } from '@angular/router';
import { Movie } from '../../model/movie';
import { UserService } from '../user.service';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent {
  userid:any;
  user:any;
  showUsers:boolean=false;
  movieList: any;
  filteredMovielist: any[] = [];
  searchQuery: string = '';
  // movielist: any; // Define the type according to your movie data
  placeholderImages: string[] = [
    'https://th.bing.com/th/id/OIP.umKoF5lz94Mv5bewZCElqwAAAA?w=131&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    'https://th.bing.com/th/id/OIP.-JjEER-rst1Auk5ytHQtywHaO0?w=115&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    'https://th.bing.com/th/id/OIP.Z7nphlbChrAxwgwZxJxspgHaGL?w=210&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    'https://th.bing.com/th/id/OIP.ZneFCUzw81CdNcHjw9czdQAAAA?w=126&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    'https://th.bing.com/th/id/OIP.bzxEdsDXC3n7iEz8fDVNXQHaKl?w=128&h=186&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    'https://th.bing.com/th/id/OIP.OgU3wxA6kJVjMvTx3K_LpwAAAA?rs=1&pid=ImgDetMain'
  ];

  constructor(private movies: MovieService,private router:Router,private userservice:UserService) {
    this.getmoviesdata();
     }

  ngOnInit(){
    this.userid=localStorage.getItem("userid");
    // console.log("userid",userid);


      this.userservice.getById(this.userid).subscribe({
        next: (user) => {
          this.user = user;
          console.log("user",user);
          if(user.role==='user')
          {
            this.showUsers=true;
            console.log("this is user");

          } else if(user.role==='admin'){
            console.log("this is admin");

          }

        },
        error: (err) => {
          console.error('Error fetching user details', err);

        }
      });

  }
  getmoviesdata() {
    // this.movies.getUserData().subscribe((data: any) => {
    //   console.log(data);
    //   this.movieList = data;
    // })
    this.movies.getUserData().subscribe((data) => {
      this.movieList = data;
      this.movieList = this.movieList.map((movie: any, index: number) => ({
        ...movie,
        imageUrl: this.placeholderImages[index % this.placeholderImages.length]
      }));
      console.log("movielist", this.movieList);
    });

  }
  toggleDetails(movie: any): void {
    movie.showDetails = !movie.showDetails;
  }
  delete(id: number) {
    this.movies.delete(id).subscribe(data => {
      console.log(data);
      this.getmoviesdata();
    })
  }
  clearSearch(){
    this.router.navigate(['/home/movie'])
    .then(() =>
    {
      window.location.reload();
    });


  }

  filterMovies() {
    if (this.searchQuery.trim() === '') {
      this.movieList = this.movieList.map((movie: any, index: number) => ({
        ...movie,
        imageUrl: this.placeholderImages[index % this.placeholderImages.length]
      }));

    } else {
      this.movieList = this.movieList.filter((movie: { title: string; }) =>
        movie.title.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  }
}
