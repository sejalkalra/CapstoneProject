import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieshowtimelistComponent } from './movieshowtimelist.component';

describe('MovieshowtimelistComponent', () => {
  let component: MovieshowtimelistComponent;
  let fixture: ComponentFixture<MovieshowtimelistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MovieshowtimelistComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MovieshowtimelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
