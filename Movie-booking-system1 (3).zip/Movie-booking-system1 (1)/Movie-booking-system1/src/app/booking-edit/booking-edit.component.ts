import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking-edit',
  templateUrl: './booking-edit.component.html',
  styleUrls: ['./booking-edit.component.css']
})
export class BookingEditComponent implements OnInit {

  booking: any

  constructor(
    private route: ActivatedRoute,
    private bookingService: BookingService,
    private router: Router
  ) { }

  // ngOnInit(): void {
  //   this.route.paramMap.subscribe(params => {
  //     var bookingId = Number(params.get('id'));
  //     this.getBookingById(bookingId);
  //   });
  // }

  // getBookingById(bookingId: number): void {
  //   this.bookingService.getBookingById(bookingId)
  //     .subscribe(data => {
  //       this.booking = data;
  //     });
  // }

  // updateBooking(): void {
  //   console.log(this.booking)
  //   this.bookingService.updateBooking(this.booking.bookingId, this.booking)
  //     .subscribe(() => {
  //       this.router.navigate(['/home/booking-list']);
  //     });
  // }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      var bookingId = Number(params.get('id'));
      this.getBookingById(bookingId);
    });
  }

  getBookingById(bookingId: number): void {
    this.bookingService.getBookingById(bookingId)
      .subscribe(data => {
        this.booking = data;
      });
  }

  updateBooking(): void {
    console.log(this.booking)
    this.bookingService.updateBooking(this.booking.bookingId, this.booking)
      .subscribe(() => {
        this.router.navigate(['/home/booking-list']);
      });
  }

  clear(){
    this.router.navigate(['/home/booking-list'])
    .then(() =>
    {
      window.location.reload();
    });

  }
}
