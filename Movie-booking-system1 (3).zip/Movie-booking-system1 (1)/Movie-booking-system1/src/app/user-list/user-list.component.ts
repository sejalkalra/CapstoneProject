import { Component } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent {
  userList: any;
  UserService: any;
  userid:any;
  user:any;
  showUsers:boolean=false;
  constructor(private users: UserService){
    this.getusersdata();
  }

  ngOnInit(){
    this.userid=localStorage.getItem("userid");
    // console.log("userid",userid);


      this.users.getById(this.userid).subscribe({
        next: (user) => {
          this.user = user;
          console.log("user",user);
          if(user.role==='user')
          {
            this.showUsers=true;
            console.log("this is user");

          } else if(user.role==='admin'){
            console.log("this is admin");

          }

        },
        error: (err) => {
          console.error('Error fetching user details', err);

        }
      });

  }
  getusersdata(){
    this.users.getUserData().subscribe((data: any) => {
      console.log(data);
      this.userList = data;
})}

delete(userId:number){
this.users.delete(userId).subscribe(data =>{
console.log(data);
this.getusersdata();
})

}
}



