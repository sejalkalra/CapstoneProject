import { Component } from '@angular/core';
import { User } from '../../model/User';
import { UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrl: './user-update.component.css'
})
export class UserUpdateComponent {
  userAdd: User = new User();
  constructor(private userService: UserService,
    private route: ActivatedRoute,
    private router:Router,) {}

    ngOnInit(): void {
      this.route.paramMap.subscribe((param) => {
        //editt:101 = @Path Varaible
        var userId = Number(param.get('userId')); // Read the product id from route
        this.getById(userId);

      });
    }

    getById(userId: number) {
      this.userService.getById(userId).subscribe((data) => {
      console.log(data);
        this.userAdd = data;
      });
    }

update() {
    this.userService.update(this.userAdd)
    .subscribe({
      next:(data) => {
        this.router.navigate(["/home/user"]);
      },
      error:(err) => {
        console.log(err);
      }
    })
  }
  back(){
    this.router.navigate(["/home/user"])
  }

}
