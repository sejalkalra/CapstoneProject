
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BookingService } from '../booking.service';
import { ShowtimeService } from '../showtime-service.service';
import { Showtime } from '../../model/Showtime.model';
import { UserService } from '../user.service';
import { User } from '../../model/User';
import { booking } from '../../model/booking';


@Component({
  selector: 'app-booking-add',
  templateUrl: './booking-add.component.html',
  styleUrls: ['./booking-add.component.css']
})
export class BookingAddComponent {

  booking: booking = {
    bookingDate: '',
    numberOfTickets: 0,
    totalPrice: 0,
    userId: 0,
    showtimeId: 0
  };
showtimeList:Showtime[]=[]
userList:any;
showError:boolean=false;
  constructor(
    private bookingService: BookingService,
    private showtimeservice:ShowtimeService,
    private userservice:UserService,
    private router: Router
  ) {
    this.showtimeservice.getAllShowtimes().subscribe(data=>{
      this.showtimeList=data
    })
    this.userservice.getUserData().subscribe(data=>{
      this.userList=data
    })

   }

  // addBooking(): void {
  //   console.log (this.booking)
  //   this.booking.user.userId = parseInt(localStorage.getItem('userid') ?? '0');
  //   this.bookingService.createBooking(this.booking)
  //     .subscribe(() => {
  //       this.router.navigate(['/home/booking-list']);
  //     });
  // }
  addBooking(): void {
    //console.log(this.booking);

    // const userId = parseInt(localStorage.getItem('userid') ?? '0');
    // if (userId > 0) {
    //   this.booking.user.userId = userId;
    // } else {
    //   console.error('Invalid user ID. Please log in again.');
    //   // Redirect to login or show an error message
    //   return;
    // }

    // this.bookingService.createBooking(this.booking)
    //   .subscribe(
    //     () => {
    //       this.router.navigate(['/home/booking-list']);
    //     },
    //     error => {
    //       console.error('Error creating booking:', error);
    //     }
    //   );

    console.log (this.booking)
    this.bookingService.createBooking(this.booking)
      .subscribe(() => {
        this.router.navigate(['/home/booking-list']);
      });
  }


  onValidation(){
    return this.booking.totalPrice&&this.booking.numberOfTickets&&this.booking.bookingDate;}

    clear(){
      this.router.navigate(['/home/booking-list'])
      .then(() =>
      {
        window.location.reload();
      });

    }
}

