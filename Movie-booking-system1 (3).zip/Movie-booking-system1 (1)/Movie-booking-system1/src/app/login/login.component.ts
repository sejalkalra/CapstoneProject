import { AuthService } from './../auth.service';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private http: HttpClient, private router: Router,private authService:AuthService) {}

  login() {
    this.authService.login(this.username, this.password).subscribe({
      next: (response) => {
        if (response.valid) {
          // Use response.user as needed
          console.log('User:', response.user);

          this.authService.setAuthenticated(true);
          alert("The login is Successful!!");
          this.router.navigate(['/home']);
        } else {
          this.errorMessage = 'Invalid credentials';
          alert("this is not correct");
        }
      },
      error: (err) => {
        console.error('Login error', err);
        this.errorMessage = 'An error occurred during login';
      }
    });
  }
  onsignup(){
    this.router.navigateByUrl('/signup');
  }
}




  // login() {
  //   this.authService.login(this.username, this.password).subscribe({
  //     next: (response) => {
  //       if (response.valid) {
  //         this.authService.setAuthenticated(true);
  //         this.router.navigate(['/home']);
  //       } else {
  //         alert('Invalid credentials');
  //       }
  //     },
  //     error: (err) => {
  //       console.error('Login error', err);
  //     }
  //   });
  // }

