import { Component } from '@angular/core';
import { MovieService } from '../movie.service';
import { Router } from '@angular/router';
import { Movie } from '../../model/movie';

@Component({
  selector: 'app-movie-add',
  templateUrl: './movie-add.component.html',
  styleUrls: ['./movie-add.component.css']
})
export class MovieAddComponent {
  showError:boolean=false;

  constructor(private movieService:MovieService,
    private router:Router) {}
  // productForm: Product = {
  //   id: 0,
  //   pname: '',
  //   price: 0
  // };
  movieAdd: Movie = new Movie();

  create(){
    this.showError=true;
    if(this.onValidation()){
      this.showError=false;
    this.movieService.createMovie(this.movieAdd)
    .subscribe({
      next:(data) => {
        this.router.navigate(["/home/movie"])
      },

    })
  }
  }
  movieList(movieList: any) {
    throw new Error('Method not implemented.');
  }

  clearSearch(){
    this.router.navigate(['/home/movie'])
    .then(() =>
    {
      window.location.reload();
    });


  }
  onValidation(){
      return this.movieAdd.description&&this.movieAdd.duration&&this.movieAdd.genre&& this.movieAdd.rating <= 10 &&this.movieAdd.title;
  }
}

