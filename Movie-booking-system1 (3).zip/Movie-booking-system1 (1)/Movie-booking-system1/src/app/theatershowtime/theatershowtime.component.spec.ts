import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TheatershowtimeComponent } from './theatershowtime.component';

describe('TheatershowtimeComponent', () => {
  let component: TheatershowtimeComponent;
  let fixture: ComponentFixture<TheatershowtimeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TheatershowtimeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TheatershowtimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
