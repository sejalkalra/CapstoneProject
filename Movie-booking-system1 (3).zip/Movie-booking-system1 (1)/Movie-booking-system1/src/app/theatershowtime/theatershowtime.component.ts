import { Component } from '@angular/core';
import { ShowtimeService } from '../showtime-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TheaterService } from '../theater.service';
import { MovieService } from '../movie.service';

@Component({
  selector: 'app-theatershowtime',
  templateUrl: './theatershowtime.component.html',
  styleUrl: './theatershowtime.component.css'
})
export class TheatershowtimeComponent {
  theaterId: any;
  movieId:any
  showtimestheater:any;
  // getShowtimesByMovieId:any;


  showtimes:any;
  constructor(private showtimeService: ShowtimeService, private router: Router,
    private theatersevice: TheaterService,
    private movieservice: MovieService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      var tid = Number(param.get('theaterId'));// Read the product id from route
      var mid = Number(param.get('movieId'));
      if (tid > 0)
        this.getBytheaterId(tid);
      else if (mid > 0)
        this.getByMovieId(mid)
      else
        this.loadShowtimes(); // Load showtimes when component initializes


    });

    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      var t = Number(param.get('theaterId'));
      console.log("ID",t);

    //   var m = Number(param.get('movieId'));
    // this.showtimeService.getShowtimesBymov(m).subscribe(data => {
    //   this.showtimes = data;
    //   console.log("get By Movie Id",this.showtimes);
    // });

    this.theatersevice.getShowtimeByTheater(t).subscribe(data => {
      this.showtimestheater = data
      console.log("showtimestheater data",this.showtimestheater);

    })


  });


  }

  getBytheaterId(tid: number) {
    this.theatersevice.getShowtimeByTheater(tid).subscribe(data => {
      this.showtimes = data
      // console.log("data",this.showtimes);

    })
  }
  getByMovieId(movieId:number){
    this.movieservice.getShowtimeByMovie(movieId).subscribe(data =>{
      this.showtimes =data


    })
  }

  loadShowtimes() {
    this.showtimeService.getAllShowtimes().subscribe(data => {
      this.showtimes = data; // Update showtimes array with fetched data
    });
  }

  deleteShowtime(id: number) {
    if (confirm('Are you sure you want to delete this showtime?')) {
      this.showtimeService.deleteShowtime(id).subscribe(() => {
        this.loadShowtimes(); // Reload showtimes after deletion
      });
    }
  }

  getShowtimesByTheaterId(theaterId: number) {
    this.showtimeService.getShowtimesByTheater(theaterId).subscribe(data => {
      this.showtimes = data;
    });
  }

  searchQuery: string = '';
  filterMovies() {
    if (this.searchQuery.trim() === '') {
    }else{
      this.showtimestheater.showtime = this.showtimestheater.showtime.filter((t: { showDate: string; }) =>
        t.showDate.toLowerCase().includes(this.searchQuery.toLowerCase())
      );}
    }

  clear(){

      window.location.reload();


  }

  cancel(){
    this.router.navigate(['/home/theater'])
    .then(() =>
    {
      window.location.reload();
    });


  }
}
