import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ShowtimeService } from '../showtime-service.service';
import { Showtime } from '../../model/Showtime.model';

@Component({
  selector: 'app-showtime-edit',
  templateUrl: './showtime-edit.component.html',
  styleUrls: ['./showtime-edit.component.css']
})
export class ShowtimeEditComponent implements OnInit {

  showtimeId!: number;
  showtime: Showtime=new Showtime;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private showtimeService: ShowtimeService
  ) { }

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    this.showtimeId = idParam ? +idParam : 0; // Convert idParam to number or set to 0 if null or undefined

    if (this.showtimeId === 0) {
      console.error('Invalid showtime ID:', idParam);
      // Handle invalid ID, e.g., redirect to showtimes list or show error message
      this.router.navigate(['/showtime-list']);
    } else {
      this.loadShowtimeDetails();
    }
  }

  loadShowtimeDetails() {
    this.showtimeService.getShowtimeById(this.showtimeId).subscribe(
      (data: Showtime) => {
        this.showtime = data; // Load showtime details into form for editing
      },
      error => {
        console.error('Error loading showtime:', error); // Handle error if necessary
      }
    );
  }

  onSubmit() {
    if (this.showtime) { // Ensure showtime object is not null or undefined
      this.showtimeService.updateShowtime(this.showtimeId, this.showtime).subscribe(
        () => {
          this.router.navigate(['/home/showtime-list']); // Navigate back to showtimes list after editing
        },
        error => {
          console.error('Error updating showtime:', error); // Handle error if necessary
        }
      );
    } else {
      console.error('Showtime object is null or undefined.');
      // Handle case where showtime object is not properly loaded
    }
  }
  clear(){
    this.router.navigate(['/home/showtime-list'])
    .then(() =>
    {
      window.location.reload();
    });

  }
}
