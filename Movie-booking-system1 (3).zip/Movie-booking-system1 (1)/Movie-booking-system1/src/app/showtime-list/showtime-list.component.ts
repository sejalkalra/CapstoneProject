import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ShowtimeService } from '../showtime-service.service';
import { Showtime } from '../../model/Showtime.model';
import { TheaterService } from '../theater.service';
import { MovieService } from '../movie.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-showtime-list',
  templateUrl: './showtime-list.component.html',
  styleUrls: ['./showtime-list.component.css']
})
export class ShowtimeListComponent implements OnInit {
  // showtimes: Showtime[] = []; // Initialize as empty array
  theaterId: any;
  showtimes:any;
  userid:any;
  user:any;
  showUsers:boolean=false;
  constructor(private showtimeService: ShowtimeService, private router: Router,
    private theatersevice: TheaterService,
    private movieservice: MovieService,
    private route: ActivatedRoute,private userservice:UserService
  ) { }

  ngOnInit(): void {

    this.userid=localStorage.getItem("userid");
    // console.log("userid",userid);


      this.userservice.getById(this.userid).subscribe({
        next: (user) => {
          this.user = user;
          console.log("user",user);
          if(user.role==='user')
          {
            this.showUsers=true;
            console.log("this is user");

          } else if(user.role==='admin'){
            console.log("this is admin");

          }

        },
        error: (err) => {
          console.error('Error fetching user details', err);

        }
      });

    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      var tid = Number(param.get('theaterId'));// Read the product id from route
      var mid = Number(param.get('movieId'));
      if (tid > 0)
        this.getBytheaterId(tid);
      else if (mid > 0)
        this.getByMovieId(mid)
      else
        this.loadShowtimes(); // Load showtimes when component initializes

    });

  }
  getBytheaterId(tid: number) {
    this.theatersevice.getShowtimeByTheater(tid).subscribe(data => {
      this.showtimes = data
    })
  }
  getByMovieId(id:number){
    this.movieservice.getShowtimeByMovie(id).subscribe(data =>{
      this.showtimes =data
    })
  }

  loadShowtimes() {
    this.showtimeService.getAllShowtimes().subscribe(data => {
      this.showtimes = data;
      console.log("allshowtime",this.showtimes);// Update showtimes array with fetched data
    });
  }

  deleteShowtime(id: number) {
    if (confirm('Are you sure you want to delete this showtime?')) {
      this.showtimeService.deleteShowtime(id).subscribe(() => {
        this.loadShowtimes(); // Reload showtimes after deletion
      });
    }
  }

  // editShowtime(id: number) {
  //   this.router.navigate(['/showtimes/edit', id]);
  // }

  getShowtimesByMovieId(movieId: number) {
    this.showtimeService.getShowtimesByMovie(movieId).subscribe(data => {
      this.showtimes = data;
    });
  }
  getShowtimesByTheaterId(theaterId: number) {
    this.showtimeService.getShowtimesByTheater(theaterId).subscribe(data => {
      this.showtimes = data;
    });
  }
}
