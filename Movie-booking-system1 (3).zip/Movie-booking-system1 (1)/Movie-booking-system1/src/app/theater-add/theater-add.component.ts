import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { TheaterService } from '../theater.service';
import { Theater } from '../../model/theater';
//import { Theater } from '../theater.model';

@Component({
  selector: 'app-theater-add',
  templateUrl: './theater-add.component.html',
})
export class TheaterAddComponent {
  theater: Theater = { theaterId: 0, name: '', location: '', capacity: 0 };
  showError:boolean=false;
  constructor(private theaterService: TheaterService, private router: Router) {}

  addTheater(): void {
    this.showError=true;
    if(this.onValidation()){
      this.showError=false;
    this.theaterService.addTheater(this.theater).subscribe(() => {
      this.router.navigate(['/home/theater']);
    });
  }
  }

  clear(){
    this.router.navigate(['/home/theater'])
    .then(() =>
    {
      window.location.reload();
    });

  }
  onValidation(){
return this.theater.name&&this.theater.capacity&&this.theater.location;}
}
