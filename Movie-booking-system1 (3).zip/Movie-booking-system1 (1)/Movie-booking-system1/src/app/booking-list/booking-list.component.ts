import { UserService } from './../user.service';
import { Component } from '@angular/core';
import { BookingService } from '../booking.service';
import { ActivatedRoute } from '@angular/router';
import { Showtime } from '../../model/Showtime.model';
import { ShowtimeService } from '../showtime-service.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrl: './booking-list.component.css'
})
export class BookingListComponent {
  userid:any;
  user:any;
  showUsers:boolean=false;
  bookingList: any[] = []
  userId: number = 1
  constructor(private bookservice: BookingService, private route: ActivatedRoute,
    private showtimeservice: ShowtimeService,private userservice:UserService
  ) {
  }
  ngOnInit(): void {
    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      var id = Number(param.get('showId')); // Read the product id from route
      if (id > 0)
        this.getByShowtimeId(id);
      else
        this.getAllBookings();

    });

 this.userid=localStorage.getItem("userid");
    // console.log("userid",userid);


      this.userservice.getById(this.userid).subscribe({
        next: (user) => {
          this.user = user;
          console.log("user",user);
          if(user.role==='user')
          {
            this.showUsers=true;
            console.log("this is user");

          } else if(user.role==='admin'){
            console.log("this is admin");

          }

        },
        error: (err) => {
          console.error('Error fetching user details', err);

        }
      });



  }
  getByShowtimeId(id: number) {
    this.showtimeservice.getBookingForShowtime(id).subscribe(data => {
      this.bookingList = data
    })
  }
  getAllBookings() {
    this.bookservice.getAllBooking().subscribe(data => {
      this.bookingList = data;
      console.log("bookings",this.bookingList);


    })
  }

  getBookingsForUser(): void {
    this.bookservice.getBookingsForUser(this.userId)
      .subscribe(data => {
        this.bookingList = data;
      });
  }
  cancelBooking(bookingId: number): void {
    this.bookservice.cancelBooking(bookingId)
      .subscribe(() => {
        this.getAllBookings();
      });
  }
}

