import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { User } from '../model/User';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http:HttpClient) {
    let apiurl="http://localhost:9200/api/users";

  }
  getUserData(){
   let apiurl="http://localhost:9200/api/users";
   return this.http.get(apiurl);
 }
 createUser(data:any)
 {
   //return this.http.post<any>(" http://localhost:3000/products",data)
   return this.http.post<any>(" http://localhost:9200/api/users",data)
   .pipe(map((res:any)=>{
     console.log(res);
     return res;
   }));
 }
 //------------------Update----------------
 getById(userId: number) {
   //return this.http.get<Product>(`http://localhost:3000/products/${id}`);
   console.log('');
   return this.http.get<User>(`http://localhost:9200/api/users/${userId}`);
  }
  update(payload:User){
   //return this.http.put(`http://localhost:3000/movies/${payload.id}`,payload);
   return this.http.put(`http://localhost:9200/api/users/${payload.userId}`,payload);

  }
   delete(userId: number){

     return this.http.delete(`http://localhost:9200/api/users/${userId}`);
   }

}
