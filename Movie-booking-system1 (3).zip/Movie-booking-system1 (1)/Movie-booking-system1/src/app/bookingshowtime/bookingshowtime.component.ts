import { Component } from '@angular/core';
import { BookingService } from '../booking.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ShowtimeService } from '../showtime-service.service';

@Component({
  selector: 'app-bookingshowtime',
  templateUrl: './bookingshowtime.component.html',
  styleUrl: './bookingshowtime.component.css'
})
export class BookingshowtimeComponent {
  bookingList: any[] = []
  userId: number = 1
  constructor(private bookservice: BookingService, private route: ActivatedRoute,
    private showtimeservice: ShowtimeService,    private router: Router

  ) {
  }
  ngOnInit(): void {
    this.route.paramMap.subscribe((param) => {
      //editt:101 = @Path Varaible
      var id = Number(param.get('showId')); // Read the product id from route
      if (id > 0)
        this.getByShowtimeId(id);
      else
        this.getAllBookings();

    });

  }
  getByShowtimeId(id: number) {
    this.showtimeservice.getBookingForShowtime(id).subscribe(data => {
      this.bookingList = data
    })
  }
  getAllBookings() {
    this.bookservice.getAllBooking().subscribe(data => {
      this.bookingList = data;
      console.log("bookings",this.bookingList);


    })
  }

  getBookingsForUser(): void {
    this.bookservice.getBookingsForUser(this.userId)
      .subscribe(data => {
        this.bookingList = data;
      });
  }
  cancelBooking(bookingId: number): void {
    this.bookservice.cancelBooking(bookingId)
      .subscribe(() => {
        this.getAllBookings();
      });
  }

  cancel(){
    this.router.navigate(['/home/booking-list'])
    .then(() =>
    {
      window.location.reload();
    });


  }
}
