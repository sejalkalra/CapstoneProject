import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingshowtimeComponent } from './bookingshowtime.component';

describe('BookingshowtimeComponent', () => {
  let component: BookingshowtimeComponent;
  let fixture: ComponentFixture<BookingshowtimeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BookingshowtimeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BookingshowtimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
