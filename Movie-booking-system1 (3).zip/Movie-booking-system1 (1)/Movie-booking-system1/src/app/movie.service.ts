import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { Movie } from '../model/movie';
import { Showtime } from '../model/Showtime.model';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
 
 
  constructor(private http:HttpClient) {


  }
  getUserData(){
   let apiurl="http://localhost:9102/api/movies";
   return this.http.get(apiurl);
 }
 createMovie(data:any)
 {
   //return this.http.post<any>(" http://localhost:3000/products",data)
   return this.http.post<any>(" http://localhost:9102/api/movies",data)
   .pipe(map((res:any)=>{
     console.log(res);
     return res;
   }));
 }
 getShowtimeByMovie(id:number){
  return this.http.get<Showtime[]>(`http://localhost:9102/api/movies/${id}/showtime`);
 }
 //------------------Update----------------
 getById(movieId: number) {
   //return this.http.get<Product>(`http://localhost:3000/products/${id}`);
   console.log('');
   return this.http.get<Movie>(`http://localhost:9102/api/movies/${movieId}`);
  }
  update(payload:Movie){
   //return this.http.put(`http://localhost:3000/movies/${payload.id}`,payload);
   return this.http.put(`http://localhost:9102/api/movies/${payload.movieId}`,payload);
  
  }
  delete(id: number){
    return this.http.delete(`http://localhost:9102/api/movies/${id}`);
  }
}

