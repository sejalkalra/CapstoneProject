import { Component } from '@angular/core';
import { User } from '../../model/User';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrl: './user-add.component.css'
})
export class UserAddComponent {
  // constructor(private userService:UserService,
  //   private router:Router) {}

  // userAdd: User = new User();

  // create(){
  //   this.userService.createUser(this.userAdd)
  //   .subscribe({
  //     next:(data) => {
  //       this.router.navigate(["/home/user"])
  //     },
  //     error:(err) => {
  //       console.log(err);
  //     }
  //   })
  // }
  // userList(userList: any) {
  //   throw new Error('Method not implemented.');
  // }
  constructor(private userService:UserService,
    private router:Router) {}
  userAdd: User = new User();
  showPassword: boolean = false;

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
  create(){
    this.userService.createUser(this.userAdd)
    .subscribe({
      next:(data) => {
        // this.router.navigate(["/users"])
        alert("Sign Up Successful!!!!")
        this.router.navigate(["/login"])

      },
      error:(err) => {
        alert("Try Again!!!!")
        console.log(err);
      }
    })
  }
  userList(userList: any) {
    throw new Error('Method not implemented.');
  }

  back(){
    this.router.navigate(["/login"])
  }
}
