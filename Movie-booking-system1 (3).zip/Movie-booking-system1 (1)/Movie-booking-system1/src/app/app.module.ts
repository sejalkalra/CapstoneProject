import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { TheaterAddComponent } from './theater-add/theater-add.component';
import { TheaterEditComponent } from './theater-edit/theater-edit.component';
import { TheaterListComponent } from './theater-list/theater-list.component';
import { BookingAddComponent } from './booking-add/booking-add.component';
import { BookingEditComponent } from './booking-edit/booking-edit.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { MovieAddComponent } from './movie-add/movie-add.component';
import { MovieEditComponent } from './movie-edit/movie-edit.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { ShowtimeAddComponent } from './showtime-add/showtime-add.component';
import { ShowtimeEditComponent } from './showtime-edit/showtime-edit.component';
import { ShowtimeListComponent } from './showtime-list/showtime-list.component';
import { UserAddComponent } from './user-add/user-add.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserUpdateComponent } from './user-update/user-update.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatFormFieldModule } from '@angular/material/form-field';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatIcon } from '@angular/material/icon';
import { MovieshowtimelistComponent } from './movieshowtimelist/movieshowtimelist.component';
import { TheatershowtimeComponent } from './theatershowtime/theatershowtime.component';
import { BookingshowtimeComponent } from './bookingshowtime/bookingshowtime.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    NavbarComponent,
    TheaterAddComponent,
    TheaterEditComponent,
    TheaterListComponent,
    BookingAddComponent,
    BookingEditComponent,
    BookingListComponent,
    MovieAddComponent,
    MovieEditComponent,
    MovieListComponent,
    ShowtimeAddComponent,
    ShowtimeEditComponent,
    ShowtimeListComponent,
    UserAddComponent,
    UserListComponent,
    UserUpdateComponent,
    MovieshowtimelistComponent,
    TheatershowtimeComponent,
    BookingshowtimeComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatToolbarModule,
    MatSidenavModule,
     MatListModule,
    MatFormFieldModule,
    MatIcon
   // NgbModule
  ],
  providers: [AuthService, AuthGuard,provideAnimationsAsync()],
  bootstrap: [AppComponent]
})
export class AppModule { }
