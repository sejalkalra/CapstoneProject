import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Theater } from '../model/theater';
import { Showtime } from '../model/Showtime.model';
//import { Theater } from '../model/theater';


@Injectable({
  providedIn: 'root'
})
export class TheaterService {
  private apiUrl = 'http://localhost:9100/api/theaters';
  //localhost:9100/api/theaters/111/showtime

  constructor(private http: HttpClient) { }

  getTheaters(): Observable<Theater[]> {
    return this.http.get<Theater[]>(`${this.apiUrl}/alltheater`);
  }
  getShowtimeByTheater(tid: number) {
    return this.http.get<Showtime[]>(`http://localhost:9100/api/theaters/theater/${tid}`);
  }

  // getTheater(id: number): Observable<Theater> {
  //   return this.http.get<Theater>(`${this.apiUrl}/theater/${id}`);
  // }
  getById(theaterId: number) {
    //return this.http.get<Product>(`http://localhost:3000/products/${id}`);
    console.log('');
    return this.http.get<Theater>(`http://localhost:9100/api/theaters/theater/${theaterId}`);
  }

  addTheater(theater: Theater): Observable<Theater> {
    return this.http.post<Theater>(`${this.apiUrl}/addtheater`, theater);
  }

  // updateTheater(theater: Theater): Observable<Theater> {
  //   return this.http.put<Theater>(`${this.apiUrl}/edittheater/${theater.theaterId}`, theater);
  // }
  // updateTheater(payload:Theater){
  //   //return this.http.put(`http://localhost:3000/movies/${payload.id}`,payload);
  //   return this.http.put(`http://localhost:9100/api/theaters/edittheater/${payload.theaterId}`,payload);

  //  }
  updateTheater(theater: Theater): Observable<Theater> {
    return this.http.put<Theater>(`${this.apiUrl}/edittheater/${theater.theaterId}`, theater);
  }


  deleteTheater(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/deletetheater/${id}`);
  }
}
