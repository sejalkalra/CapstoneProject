import { Showtime } from "./Showtime.model";
import { User } from "./User";

export class booking{
    bookingDate!: string;
    numberOfTickets!: number;
    totalPrice!: number;
    userId!:number;
    showtimeId!:number;
    // user!: User;
    // showtime!: Showtime;
}
