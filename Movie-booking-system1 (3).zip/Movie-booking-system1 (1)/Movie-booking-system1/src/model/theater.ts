export class Theater {
    theaterId!: number;
    name!: string;
    location!: string;
    capacity!: number;
  }
