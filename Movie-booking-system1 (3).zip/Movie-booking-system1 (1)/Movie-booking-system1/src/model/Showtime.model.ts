export class Showtime {

 movieId!: number;
 theaterId!: number;
 showDate!: string;
 showTime!: string;
 showtimeId!: number;// Default to 0 if not provided

}
