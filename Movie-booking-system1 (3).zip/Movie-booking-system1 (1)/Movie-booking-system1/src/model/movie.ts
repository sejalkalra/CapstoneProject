export class Movie {
    movieId!: number;
    title!: string;
    description!: string;
    genre!: string;
    duration!: number;
    rating!: number;
  }